major = 1
minor = 4

print(f"La version major es = {major}")
print(f"La version miner es = {minor}")
